//
//  Constituencies.swift
//  ParliamentApp
//
//  Created by Monami Kirjavainen on 15.4.2026.
//  Student number: 2400479
//

import SwiftUI
import SwiftData

struct Constituencies: View {
    @Query var members: [ParliamentMemberModel]
    
    var constituencies: [String]{
        Array(Set(members.map { $0.constituency })).sorted()
    }
    var body: some View {
        VStack(alignment: .leading) {
            Text("Constituencies")
                .font(.title2)
                .bold()
                .padding(.horizontal)

            List(constituencies, id: \.self) { constituency in
                NavigationLink {
                    ConstituencyDetails(constituency: constituency)
                } label: {
                    Text(constituency)
                }
            }
        }
    }

}

#Preview {
    Constituencies()
}
